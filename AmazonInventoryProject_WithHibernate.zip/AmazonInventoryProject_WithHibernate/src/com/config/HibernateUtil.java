package com.config;

import java.util.HashMap;
import java.util.Map;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Environment;
import com.model.User;
import com.model.Product;  // Make sure this import is here
import com.model.Cart;    // Add this import for the Cart class

public class HibernateUtil {
    private static SessionFactory sf;
    private static StandardServiceRegistry registry;

    public static SessionFactory getSessionFactory() {
        try {
            if (sf == null) {
                // Connection properties
                Map<String, Object> settings = new HashMap<>();
                settings.put(Environment.JAKARTA_JDBC_DRIVER, "com.mysql.cj.jdbc.Driver");
                settings.put(Environment.JAKARTA_JDBC_URL, "jdbc:mysql://localhost:3306/monika_hibernate");
                settings.put(Environment.JAKARTA_JDBC_USER, "root");
                settings.put(Environment.JAKARTA_JDBC_PASSWORD, "root");

                // Hibernate properties
                settings.put(Environment.DIALECT, "org.hibernate.dialect.MySQL8Dialect");
                settings.put(Environment.HBM2DDL_AUTO, "update"); // Automatically creates or updates tables
                settings.put(Environment.SHOW_SQL, "true");

                // Optional: Enable 2nd level cache
                settings.put(Environment.USE_SECOND_LEVEL_CACHE, "true");
                settings.put(Environment.CACHE_REGION_FACTORY, "org.hibernate.cache.jcache.JCacheRegionFactory");
                settings.put("hibernate.javax.cache.provider", "org.ehcache.jsr107.EhcacheCachingProvider");

                // Create StandardServiceRegistryBuilder
                registry = new StandardServiceRegistryBuilder().applySettings(settings).build();

                MetadataSources sources = new MetadataSources(registry);
                sources.addAnnotatedClass(User.class);
                sources.addAnnotatedClass(Product.class);  // Register Product class
                sources.addAnnotatedClass(Cart.class);    // Register Cart class

                // Build metadata and SessionFactory
                Metadata metadata = sources.getMetadataBuilder().build();
                sf = metadata.getSessionFactoryBuilder().build();
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("SessionFactory creation failed. Check configuration.");
        }
        return sf;
    }
}
