/*
 * User Registration and Login Methods 
 */

package com.user;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.config.HibernateUtil;
import com.model.User;

public class UserService {

    public void registerUser(int id, String username, String password) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            User user = new User();
            user.setUserId(id);
            user.setUsername(username);
            user.setPassword(password);
            session.save(user);
            tx.commit();
            System.out.println("User registered successfully.");
        }
    }

    public boolean loginUser(int id, String password) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            User user = session.get(User.class, id);
            if (user != null && user.getPassword().equals(password)) {
                System.out.println("Login successful.");
                return true;
            } else {
                System.out.println("Invalid credentials.");
                return false;
            }
        }
    }
}


