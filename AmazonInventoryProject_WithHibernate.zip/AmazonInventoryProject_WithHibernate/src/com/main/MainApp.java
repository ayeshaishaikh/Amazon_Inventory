/*
 * here we create user module and product module
 * in user provide 2 choice register or login
 * in product we fetch and delete
 */

package com.main;

import com.product.ProductService;
import com.user.UserService;

import java.util.Scanner;

public class MainApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        UserService userService = new UserService();
        ProductService productService = new ProductService();

        while (true) {  // Infinite loop to keep showing the options after each operation
            System.out.println("\nChoose an option:");
            System.out.println("1. Register User");
            System.out.println("2. Login User");
            System.out.println("3. Add Product");
            System.out.println("4. Fetch Product by ID");
            System.out.println("5. Delete Product by ID");
            System.out.println("6. Exit");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    // Register User
                    System.out.print("Enter User ID: ");
                    int userId = sc.nextInt();
                    sc.nextLine(); // Consume newline
                    System.out.print("Enter Username: ");
                    String username = sc.nextLine();
                    System.out.print("Enter Password: ");
                    String password = sc.nextLine();
                    userService.registerUser(userId, username, password);
                    break;

                case 2:
                    // Login User
                    System.out.print("Enter User ID: ");
                    int loginId = sc.nextInt();
                    sc.nextLine(); // Consume newline
                    System.out.print("Enter Password: ");
                    String loginPassword = sc.nextLine();
                    userService.loginUser(loginId, loginPassword);
                    break;

                case 3:
                    // Add a product to the database
                    productService.addProduct();
                    break;

                case 4:
                    // Fetch a product by ID
                    System.out.print("Enter Product ID to fetch: ");
                    int fetchId = sc.nextInt();
                    productService.fetchProduct(fetchId);
                    break;

                case 5:
                    // Delete a product by ID
                    System.out.print("Enter Product ID to delete and add to cart: ");
                    int deleteId = sc.nextInt();
                    productService.deleteProduct(deleteId);
                    break;

                case 6:
                    // Exit the loop and terminate the program
                    System.out.println("Exiting the program.");
                    sc.close();
                    return;

                default:
                    System.out.println("Invalid option. Please choose a valid number.");
            }
        }
    }
}
