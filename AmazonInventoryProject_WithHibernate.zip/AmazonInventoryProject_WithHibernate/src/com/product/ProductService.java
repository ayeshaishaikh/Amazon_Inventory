/*
 * here we created a method which is fetch product and 
 * delete product
 * and also we have inserted data in product table
 */

package com.product;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.config.HibernateUtil;
import com.model.Product;
import com.model.Cart;

public class ProductService {

    public void addProduct() {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();
            Scanner scanner = new Scanner(System.in);
            
            Product product = new Product();

            System.out.print("Enter Product ID: ");
            product.setProductId(scanner.nextInt());
            scanner.nextLine();

            System.out.print("Enter Product Name: ");
            product.setProductName(scanner.nextLine());

            System.out.print("Enter Product Price: ");
            product.setProductPrice(scanner.nextDouble());
            scanner.nextLine();

            System.out.print("Enter Product Description: ");
            product.setProductDesc(scanner.nextLine());

            session.save(product);
            tx.commit();
            System.out.println("Product added successfully.");
        }
    }

    public Product fetchProduct(int productId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Product product = session.get(Product.class, productId);
            if (product != null) {
                System.out.println("Product found: " + product);
                return product;
            } else {
                System.out.println("Product not found.");
                return null;
            }
        }
    }

    public void deleteProduct(int productId) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Transaction tx = session.beginTransaction();

            Product product = session.get(Product.class, productId);
            if (product != null) {
                // Create Cart entry for the product to be deleted
                Cart cartItem = new Cart();
                cartItem.setProductId(product.getProductId());
                cartItem.setProductName(product.getProductName());
                cartItem.setProductPrice(product.getProductPrice());
                cartItem.setProductDesc(product.getProductDesc());

                // Save to cart
                session.save(cartItem);

                // Delete from product inventory
                session.delete(product);
                System.out.println("Product deleted from inventory and added to cart.");
            } else {
                System.out.println("Product with ID " + productId + " not found.");
            }
            tx.commit();
        }
    }
}
